#include "ti_msp_dl_config.h"
#include "app_config.h"
#include "app_board_test.h"
#include "app_car_base.h"
#include "app_h26.h"
#include "app_ball_link.h"
#include "app_radio.h"
#include "app_control.h"
#include "app_line.h"
#include "BeepLed.h"
#include "Encoder.h"
#include "IR8.h"
#include "Key.h"
#include "Motor.h"
#include "OLED.h"
#include "RodEncoder.h"
#include "RodStepper.h"
#include "Serial.h"
#include "DebugSerial.h"
#include "Timer.h"
#include "cmsis_compiler.h"
#include <stdint.h>

#if ECAR_VISION_TRACK_MODE
#include "app_vision_link.h"
#include "app_vision_track.h"
#endif

volatile uint8_t g_task_1ms_count  = 0U;
volatile uint8_t g_task_5ms_count  = 0U;
volatile uint8_t g_task_10ms_count = 0U;
volatile uint8_t g_task_100ms_count = 0U;
volatile uint8_t g_task_200ms_count = 0U;

__attribute__((used, section(".rodata.flash_tail_pad")))
static const uint8_t s_flashTailPadForKeilFlm[0x10] = { 0U };

static uint8_t Main_TakeTaskCounterAll(volatile uint8_t *counter)
{
    uint8_t count;
    uint32_t primask = __get_PRIMASK();

    __disable_irq();
    count = *counter;
    *counter = 0U;
    if (primask == 0U)
    {
        __enable_irq();
    }

    return count;
}

#if CAR_ENCODER_MINIMAL_DEBUG
static void Main_PrintfSingleFieldTest(void)
{
    Serial_Printf("[printf-test]\r\n");
    Serial_Printf("risr=%lu\r\n", (unsigned long)Encoder_GetRightIsrCount());
    Serial_Printf("rign=%lu\r\n", (unsigned long)Encoder_GetRightSameAIgnored());
    Serial_Printf("rstat=%lu\r\n", (unsigned long)Encoder_GetRightStatusCount());
    Serial_Printf("rraw=%ld\r\n", (long)Encoder_GetRightLastRawDeltaBeforeLimit());
    Serial_Printf("rlim=%lu\r\n", (unsigned long)Encoder_GetRightLimitHitCount());
    Serial_Printf("rget=%lu\r\n", (unsigned long)Encoder_GetRightGetDeltaCount());
    Serial_Printf("rnz=%lu\r\n", (unsigned long)Encoder_GetRightNonZeroGetCount());
    Serial_Printf("rmax=%ld\r\n", (long)Encoder_GetRightMaxRawDelta());
}
#endif

int main(void)
{
    SYSCFG_DL_init();

#if CAR_ENCODER_MINIMAL_DEBUG

    Serial_Init();
    Encoder_Init();
    Encoder_DebugPrintDirectNoPrintf("[enc-direct-before-timer]");
    Timer_Init();
    Encoder_DebugPrintDirectNoPrintf("[enc-direct-after-timer]");

    while (1)
    {
        static uint16_t printMs = 0U;
        uint8_t taskCount = Main_TakeTaskCounterAll(&g_task_1ms_count);

        while (taskCount > 0U)
        {
            taskCount--;
            printMs++;
            if (printMs >= 1000U)
            {
                printMs = 0U;
                Encoder_DebugPrintDirectNoPrintf("[enc-direct-before-getdelta]");

                {
                    int16_t rd = Encoder_GetRightDelta();
                    Serial_Printf("[getdelta-test]\r\n");
                    Serial_Printf("rd=%d\r\n", (int)rd);
                }

                Encoder_DebugPrintDirectNoPrintf("[enc-direct-after-getdelta]");
                Encoder_DebugPrintGetterNoPrintf("[enc-getter-after-getdelta]");
                Main_PrintfSingleFieldTest();
            }
        }
    }

#elif ECAR_VISION_TRACK_MODE

    {
        uint8_t key;

        Key_Init();
        Motor_Init();
        Motor_StopAll();
        Encoder_Init();
        Serial_Init();

#if VISION_TRACK_DEBUG_ENABLE
        DebugSerial_Init();
#endif

        App_Control_Init();
        App_Control_ForcePWMZero();

        App_VisionLink_Init();
        App_VisionTrack_Init();

        Timer_Init();

        while (1)
        {
            uint8_t taskCount;

            key = Key_GetNum();
            App_VisionTrack_HandleKey(key);

            Main_TakeTaskCounterAll(&g_task_1ms_count);

            taskCount = Main_TakeTaskCounterAll(&g_task_5ms_count);
            if (taskCount > 0U)
            {
                App_Control_UpdateEncoderSpeed(
                    (uint16_t)taskCount * CAR_ENCODER_SPEED_PERIOD_MS);
            }

            taskCount = Main_TakeTaskCounterAll(&g_task_10ms_count);
            if (taskCount > 0U)
            {
                App_VisionLink_Task10ms();
                App_VisionTrack_Task10ms();
            }

#if VISION_TRACK_DEBUG_ENABLE
            if (Main_TakeTaskCounterAll(&g_task_100ms_count) > 0U)
            {
                App_VisionTrack_Task100ms();
            }
#else
            Main_TakeTaskCounterAll(&g_task_100ms_count);
#endif
        }
    }

#elif ECAR_BOARD_TEST_MODE

    Key_Init();
    IR8_Init();
    Motor_Init();
    Motor_StopAll();
    Encoder_Init();
    BeepLed_Init();
    DebugSerial_Init();
#if !CAR_TEST_MOTOR_ENABLE && !CAR_TEST_SPEED_PID_ENABLE
    CarBase_Init();
#endif

#if ECAR_TEST_RADIO_ENABLE
    App_Radio_Init();
#endif

#if CAR_OLED_ENABLE
    OLED_Init();
    OLED_Clear();
#endif

    BoardTest_Init();

    Timer_Init();

    while (1)
    {
        uint8_t taskCount;

        (void)Main_TakeTaskCounterAll(&g_task_1ms_count);

        taskCount = Main_TakeTaskCounterAll(&g_task_5ms_count);
        if (taskCount > 0U)
        {
            App_Control_UpdateEncoderSpeed((uint16_t)taskCount * CAR_ENCODER_SPEED_PERIOD_MS);
        }

        taskCount = Main_TakeTaskCounterAll(&g_task_10ms_count);
        if (taskCount > 2U)
        {
            taskCount = 2U;
        }
        while (taskCount > 0U)
        {
            DebugSerial_Task10ms();
            BoardTest_Task10ms();
            taskCount--;
        }

        if (Main_TakeTaskCounterAll(&g_task_100ms_count) > 0U)
        {
            BoardTest_Task100ms();
        }

        if (Main_TakeTaskCounterAll(&g_task_200ms_count) > 0U)
        {
            BoardTest_Task200ms();
        }
    }

#elif APP_MODE_H26

    Key_Init();
    IR8_Init();
    Motor_Init();
    Motor_StopAll();
    Encoder_Init();
    RodEncoder_Init();
    RodStepper_Init();
    Serial_Init();
    BeepLed_Init();
    DebugSerial_Init();
    /* H26 formal task does not use servo; future ball mechanism uses an independent stepper module. */
    CarBase_Init();
    App_Line_GPIOForceInit();

#if CAR_OLED_ENABLE
    OLED_Init();
    OLED_Clear();
#endif

    H26_Init();
#if CAR_OLED_ENABLE
    H26_Task200ms();
#endif
    Timer_Init();

    DebugSerial_SendString("[boot,mode=h26]\r\n");

    while (1)
    {
        uint8_t taskCount;

        (void)Main_TakeTaskCounterAll(&g_task_1ms_count);

        taskCount = Main_TakeTaskCounterAll(&g_task_5ms_count);
        if (taskCount > 0U)
        {
            App_Control_UpdateEncoderSpeed(
                (uint16_t)taskCount * CAR_ENCODER_SPEED_PERIOD_MS);
        }

        taskCount = Main_TakeTaskCounterAll(&g_task_10ms_count);
        if (taskCount > 2U)
        {
            taskCount = 2U;
        }
        while (taskCount > 0U)
        {
            App_BallLink_Task10ms();
            DebugSerial_Task10ms();
            H26_Task10ms();
            taskCount--;
        }

        H26_KeyProcess();

        if (Main_TakeTaskCounterAll(&g_task_100ms_count) > 0U)
        {
            H26_Task100ms();
        }

        if (Main_TakeTaskCounterAll(&g_task_200ms_count) > 0U)
        {
            H26_Task200ms();
        }
    }

#else

    Key_Init();
    IR8_Init();
    Motor_Init();
    Motor_StopAll();
    Encoder_Init();
    BeepLed_Init();
    DebugSerial_Init();
    CarBase_Init();

#if CAR_OLED_ENABLE
    OLED_Init();
    OLED_Clear();
#endif

    Timer_Init();

    DebugSerial_SendString("[boot,mode=safe-idle]\r\n");

    while (1)
    {
        uint8_t taskCount;

        (void)Main_TakeTaskCounterAll(&g_task_1ms_count);

        taskCount = Main_TakeTaskCounterAll(&g_task_5ms_count);
        if (taskCount > 0U)
        {
            App_Control_UpdateEncoderSpeed((uint16_t)taskCount * CAR_ENCODER_SPEED_PERIOD_MS);
        }

        taskCount = Main_TakeTaskCounterAll(&g_task_10ms_count);
        if (taskCount > 2U)
        {
            taskCount = 2U;
        }
        while (taskCount > 0U)
        {
            DebugSerial_Task10ms();
            CarBase_Task10ms();
            taskCount--;
        }

        if (Main_TakeTaskCounterAll(&g_task_100ms_count) > 0U)
        {
            CarBase_Task100ms();
        }

        if (Main_TakeTaskCounterAll(&g_task_200ms_count) > 0U)
        {
            CarBase_Task200ms();
        }
    }

#endif
}
