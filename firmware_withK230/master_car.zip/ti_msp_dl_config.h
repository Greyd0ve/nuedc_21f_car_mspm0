/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)



#define CPUCLK_FREQ                                                     32000000



/* Defines for PWM_MOTOR */
#define PWM_MOTOR_INST                                                     TIMG0
#define PWM_MOTOR_INST_IRQHandler                               TIMG0_IRQHandler
#define PWM_MOTOR_INST_INT_IRQN                                 (TIMG0_INT_IRQn)
#define PWM_MOTOR_INST_CLK_FREQ                                         32000000
/* GPIO defines for channel 0 */
#define GPIO_PWM_MOTOR_C0_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C0_PIN                                     DL_GPIO_PIN_12
#define GPIO_PWM_MOTOR_C0_IOMUX                                  (IOMUX_PINCM34)
#define GPIO_PWM_MOTOR_C0_IOMUX_FUNC                 IOMUX_PINCM34_PF_TIMG0_CCP0
#define GPIO_PWM_MOTOR_C0_IDX                                DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_PWM_MOTOR_C1_PORT                                             GPIOA
#define GPIO_PWM_MOTOR_C1_PIN                                     DL_GPIO_PIN_13
#define GPIO_PWM_MOTOR_C1_IOMUX                                  (IOMUX_PINCM35)
#define GPIO_PWM_MOTOR_C1_IOMUX_FUNC                 IOMUX_PINCM35_PF_TIMG0_CCP1
#define GPIO_PWM_MOTOR_C1_IDX                                DL_TIMER_CC_1_INDEX

/* Defines for PWM_ROD_STEP */
#define PWM_ROD_STEP_INST                                                  TIMG7
#define PWM_ROD_STEP_INST_IRQHandler                            TIMG7_IRQHandler
#define PWM_ROD_STEP_INST_INT_IRQN                              (TIMG7_INT_IRQn)
#define PWM_ROD_STEP_INST_CLK_FREQ                                       1000000
/* GPIO defines for channel 1 */
#define GPIO_PWM_ROD_STEP_C1_PORT                                          GPIOA
#define GPIO_PWM_ROD_STEP_C1_PIN                                   DL_GPIO_PIN_2
#define GPIO_PWM_ROD_STEP_C1_IOMUX                                (IOMUX_PINCM7)
#define GPIO_PWM_ROD_STEP_C1_IOMUX_FUNC               IOMUX_PINCM7_PF_TIMG7_CCP1
#define GPIO_PWM_ROD_STEP_C1_IDX                             DL_TIMER_CC_1_INDEX



/* Defines for TIMER_SYS */
#define TIMER_SYS_INST                                                   (TIMG6)
#define TIMER_SYS_INST_IRQHandler                               TIMG6_IRQHandler
#define TIMER_SYS_INST_INT_IRQN                                 (TIMG6_INT_IRQn)
#define TIMER_SYS_INST_LOAD_VALUE                                         (124U)




/* Defines for I2C_SHARED */
#define I2C_SHARED_INST                                                     I2C0
#define I2C_SHARED_INST_IRQHandler                               I2C0_IRQHandler
#define I2C_SHARED_INST_INT_IRQN                                   I2C0_INT_IRQn
#define I2C_SHARED_BUS_SPEED_HZ                                           100000
#define GPIO_I2C_SHARED_SDA_PORT                                           GPIOA
#define GPIO_I2C_SHARED_SDA_PIN                                   DL_GPIO_PIN_28
#define GPIO_I2C_SHARED_IOMUX_SDA                                 (IOMUX_PINCM3)
#define GPIO_I2C_SHARED_IOMUX_SDA_FUNC                  IOMUX_PINCM3_PF_I2C0_SDA
#define GPIO_I2C_SHARED_SCL_PORT                                           GPIOA
#define GPIO_I2C_SHARED_SCL_PIN                                   DL_GPIO_PIN_31
#define GPIO_I2C_SHARED_IOMUX_SCL                                 (IOMUX_PINCM6)
#define GPIO_I2C_SHARED_IOMUX_SCL_FUNC                  IOMUX_PINCM6_PF_I2C0_SCL


/* Defines for UART_DEBUG */
#define UART_DEBUG_INST                                                    UART0
#define UART_DEBUG_INST_FREQUENCY                                       32000000
#define UART_DEBUG_INST_IRQHandler                              UART0_IRQHandler
#define UART_DEBUG_INST_INT_IRQN                                  UART0_INT_IRQn
#define GPIO_UART_DEBUG_RX_PORT                                            GPIOA
#define GPIO_UART_DEBUG_TX_PORT                                            GPIOA
#define GPIO_UART_DEBUG_RX_PIN                                     DL_GPIO_PIN_1
#define GPIO_UART_DEBUG_TX_PIN                                     DL_GPIO_PIN_0
#define GPIO_UART_DEBUG_IOMUX_RX                                  (IOMUX_PINCM2)
#define GPIO_UART_DEBUG_IOMUX_TX                                  (IOMUX_PINCM1)
#define GPIO_UART_DEBUG_IOMUX_RX_FUNC                   IOMUX_PINCM2_PF_UART0_RX
#define GPIO_UART_DEBUG_IOMUX_TX_FUNC                   IOMUX_PINCM1_PF_UART0_TX
#define UART_DEBUG_BAUD_RATE                                              (9600)
#define UART_DEBUG_IBRD_32_MHZ_9600_BAUD                                   (208)
#define UART_DEBUG_FBRD_32_MHZ_9600_BAUD                                    (21)
/* Defines for UART_K230 */
#define UART_K230_INST                                                     UART1
#define UART_K230_INST_FREQUENCY                                        32000000
#define UART_K230_INST_IRQHandler                               UART1_IRQHandler
#define UART_K230_INST_INT_IRQN                                   UART1_INT_IRQn
#define GPIO_UART_K230_RX_PORT                                             GPIOB
#define GPIO_UART_K230_TX_PORT                                             GPIOB
#define GPIO_UART_K230_RX_PIN                                      DL_GPIO_PIN_7
#define GPIO_UART_K230_TX_PIN                                      DL_GPIO_PIN_6
#define GPIO_UART_K230_IOMUX_RX                                  (IOMUX_PINCM24)
#define GPIO_UART_K230_IOMUX_TX                                  (IOMUX_PINCM23)
#define GPIO_UART_K230_IOMUX_RX_FUNC                   IOMUX_PINCM24_PF_UART1_RX
#define GPIO_UART_K230_IOMUX_TX_FUNC                   IOMUX_PINCM23_PF_UART1_TX
#define UART_K230_BAUD_RATE                                             (460800)
#define UART_K230_IBRD_32_MHZ_460800_BAUD                                    (4)
#define UART_K230_FBRD_32_MHZ_460800_BAUD                                   (22)
/* Defines for UART_JY61P */
#define UART_JY61P_INST                                                    UART2
#define UART_JY61P_INST_FREQUENCY                                       32000000
#define UART_JY61P_INST_IRQHandler                              UART2_IRQHandler
#define UART_JY61P_INST_INT_IRQN                                  UART2_INT_IRQn
#define GPIO_UART_JY61P_RX_PORT                                            GPIOA
#define GPIO_UART_JY61P_TX_PORT                                            GPIOA
#define GPIO_UART_JY61P_RX_PIN                                    DL_GPIO_PIN_24
#define GPIO_UART_JY61P_TX_PIN                                    DL_GPIO_PIN_23
#define GPIO_UART_JY61P_IOMUX_RX                                 (IOMUX_PINCM54)
#define GPIO_UART_JY61P_IOMUX_TX                                 (IOMUX_PINCM53)
#define GPIO_UART_JY61P_IOMUX_RX_FUNC                  IOMUX_PINCM54_PF_UART2_RX
#define GPIO_UART_JY61P_IOMUX_TX_FUNC                  IOMUX_PINCM53_PF_UART2_TX
#define UART_JY61P_BAUD_RATE                                              (9600)
#define UART_JY61P_IBRD_32_MHZ_9600_BAUD                                   (208)
#define UART_JY61P_FBRD_32_MHZ_9600_BAUD                                    (21)





/* Defines for L_IN1: GPIOB.17 with pinCMx 43 on package pin 14 */
#define GPIO_MOTOR_L_IN1_PORT                                            (GPIOB)
#define GPIO_MOTOR_L_IN1_PIN                                    (DL_GPIO_PIN_17)
#define GPIO_MOTOR_L_IN1_IOMUX                                   (IOMUX_PINCM43)
/* Defines for L_IN2: GPIOB.19 with pinCMx 45 on package pin 16 */
#define GPIO_MOTOR_L_IN2_PORT                                            (GPIOB)
#define GPIO_MOTOR_L_IN2_PIN                                    (DL_GPIO_PIN_19)
#define GPIO_MOTOR_L_IN2_IOMUX                                   (IOMUX_PINCM45)
/* Defines for R_IN1: GPIOA.16 with pinCMx 38 on package pin 9 */
#define GPIO_MOTOR_R_IN1_PORT                                            (GPIOA)
#define GPIO_MOTOR_R_IN1_PIN                                    (DL_GPIO_PIN_16)
#define GPIO_MOTOR_R_IN1_IOMUX                                   (IOMUX_PINCM38)
/* Defines for R_IN2: GPIOB.24 with pinCMx 52 on package pin 23 */
#define GPIO_MOTOR_R_IN2_PORT                                            (GPIOB)
#define GPIO_MOTOR_R_IN2_PIN                                    (DL_GPIO_PIN_24)
#define GPIO_MOTOR_R_IN2_IOMUX                                   (IOMUX_PINCM52)
/* Port definition for Pin Group GPIO_ENCODER */
#define GPIO_ENCODER_PORT                                                (GPIOA)

/* Defines for L_A: GPIOA.26 with pinCMx 59 on package pin 30 */
// pins affected by this interrupt request:["L_A","R_A"]
#define GPIO_ENCODER_INT_IRQN                                   (GPIOA_INT_IRQn)
#define GPIO_ENCODER_INT_IIDX                   (DL_INTERRUPT_GROUP1_IIDX_GPIOA)
#define GPIO_ENCODER_L_A_IIDX                               (DL_GPIO_IIDX_DIO26)
#define GPIO_ENCODER_L_A_PIN                                    (DL_GPIO_PIN_26)
#define GPIO_ENCODER_L_A_IOMUX                                   (IOMUX_PINCM59)
/* Defines for L_B: GPIOA.27 with pinCMx 60 on package pin 31 */
#define GPIO_ENCODER_L_B_PIN                                    (DL_GPIO_PIN_27)
#define GPIO_ENCODER_L_B_IOMUX                                   (IOMUX_PINCM60)
/* Defines for R_A: GPIOA.25 with pinCMx 55 on package pin 26 */
#define GPIO_ENCODER_R_A_IIDX                               (DL_GPIO_IIDX_DIO25)
#define GPIO_ENCODER_R_A_PIN                                    (DL_GPIO_PIN_25)
#define GPIO_ENCODER_R_A_IOMUX                                   (IOMUX_PINCM55)
/* Defines for R_B: GPIOA.14 with pinCMx 36 on package pin 7 */
#define GPIO_ENCODER_R_B_PIN                                    (DL_GPIO_PIN_14)
#define GPIO_ENCODER_R_B_IOMUX                                   (IOMUX_PINCM36)
/* Defines for X1: GPIOB.23 with pinCMx 51 on package pin 22 */
#define GPIO_IR8_X1_PORT                                                 (GPIOB)
#define GPIO_IR8_X1_PIN                                         (DL_GPIO_PIN_23)
#define GPIO_IR8_X1_IOMUX                                        (IOMUX_PINCM51)
/* Defines for X2: GPIOB.11 with pinCMx 28 on package pin 63 */
#define GPIO_IR8_X2_PORT                                                 (GPIOB)
#define GPIO_IR8_X2_PIN                                         (DL_GPIO_PIN_11)
#define GPIO_IR8_X2_IOMUX                                        (IOMUX_PINCM28)
/* Defines for X3: GPIOB.13 with pinCMx 30 on package pin 1 */
#define GPIO_IR8_X3_PORT                                                 (GPIOB)
#define GPIO_IR8_X3_PIN                                         (DL_GPIO_PIN_13)
#define GPIO_IR8_X3_IOMUX                                        (IOMUX_PINCM30)
/* Defines for X4: GPIOB.1 with pinCMx 13 on package pin 48 */
#define GPIO_IR8_X4_PORT                                                 (GPIOB)
#define GPIO_IR8_X4_PIN                                          (DL_GPIO_PIN_1)
#define GPIO_IR8_X4_IOMUX                                        (IOMUX_PINCM13)
/* Defines for X5: GPIOB.14 with pinCMx 31 on package pin 2 */
#define GPIO_IR8_X5_PORT                                                 (GPIOB)
#define GPIO_IR8_X5_PIN                                         (DL_GPIO_PIN_14)
#define GPIO_IR8_X5_IOMUX                                        (IOMUX_PINCM31)
/* Defines for X6: GPIOB.4 with pinCMx 17 on package pin 52 */
#define GPIO_IR8_X6_PORT                                                 (GPIOB)
#define GPIO_IR8_X6_PIN                                          (DL_GPIO_PIN_4)
#define GPIO_IR8_X6_IOMUX                                        (IOMUX_PINCM17)
/* Defines for X7: GPIOA.22 with pinCMx 47 on package pin 18 */
#define GPIO_IR8_X7_PORT                                                 (GPIOA)
#define GPIO_IR8_X7_PIN                                         (DL_GPIO_PIN_22)
#define GPIO_IR8_X7_IOMUX                                        (IOMUX_PINCM47)
/* Defines for X8: GPIOA.15 with pinCMx 37 on package pin 8 */
#define GPIO_IR8_X8_PORT                                                 (GPIOA)
#define GPIO_IR8_X8_PIN                                         (DL_GPIO_PIN_15)
#define GPIO_IR8_X8_IOMUX                                        (IOMUX_PINCM37)
/* Defines for KEY1: GPIOB.22 with pinCMx 50 on package pin 21 */
#define GPIO_KEYS_KEY1_PORT                                              (GPIOB)
#define GPIO_KEYS_KEY1_PIN                                      (DL_GPIO_PIN_22)
#define GPIO_KEYS_KEY1_IOMUX                                     (IOMUX_PINCM50)
/* Defines for KEY2: GPIOA.30 with pinCMx 5 on package pin 37 */
#define GPIO_KEYS_KEY2_PORT                                              (GPIOA)
#define GPIO_KEYS_KEY2_PIN                                      (DL_GPIO_PIN_30)
#define GPIO_KEYS_KEY2_IOMUX                                      (IOMUX_PINCM5)
/* Defines for KEY3: GPIOB.27 with pinCMx 58 on package pin 29 */
#define GPIO_KEYS_KEY3_PORT                                              (GPIOB)
#define GPIO_KEYS_KEY3_PIN                                      (DL_GPIO_PIN_27)
#define GPIO_KEYS_KEY3_IOMUX                                     (IOMUX_PINCM58)
/* Defines for KEY4: GPIOA.29 with pinCMx 4 on package pin 36 */
#define GPIO_KEYS_KEY4_PORT                                              (GPIOA)
#define GPIO_KEYS_KEY4_PIN                                      (DL_GPIO_PIN_29)
#define GPIO_KEYS_KEY4_IOMUX                                      (IOMUX_PINCM4)
/* Port definition for Pin Group GPIO_BOARD_IO */
#define GPIO_BOARD_IO_PORT                                               (GPIOA)

/* Defines for BEEP: GPIOA.7 with pinCMx 14 on package pin 49 */
#define GPIO_BOARD_IO_BEEP_PIN                                   (DL_GPIO_PIN_7)
#define GPIO_BOARD_IO_BEEP_IOMUX                                 (IOMUX_PINCM14)
/* Defines for NRF_CE: GPIOB.20 with pinCMx 48 on package pin 19 */
#define GPIO_NRF_NRF_CE_PORT                                             (GPIOB)
#define GPIO_NRF_NRF_CE_PIN                                     (DL_GPIO_PIN_20)
#define GPIO_NRF_NRF_CE_IOMUX                                    (IOMUX_PINCM48)
/* Defines for NRF_CSN: GPIOA.8 with pinCMx 19 on package pin 54 */
#define GPIO_NRF_NRF_CSN_PORT                                            (GPIOA)
#define GPIO_NRF_NRF_CSN_PIN                                     (DL_GPIO_PIN_8)
#define GPIO_NRF_NRF_CSN_IOMUX                                   (IOMUX_PINCM19)
/* Defines for NRF_SCK: GPIOA.11 with pinCMx 22 on package pin 57 */
#define GPIO_NRF_NRF_SCK_PORT                                            (GPIOA)
#define GPIO_NRF_NRF_SCK_PIN                                    (DL_GPIO_PIN_11)
#define GPIO_NRF_NRF_SCK_IOMUX                                   (IOMUX_PINCM22)
/* Defines for NRF_MOSI: GPIOA.9 with pinCMx 20 on package pin 55 */
#define GPIO_NRF_NRF_MOSI_PORT                                           (GPIOA)
#define GPIO_NRF_NRF_MOSI_PIN                                    (DL_GPIO_PIN_9)
#define GPIO_NRF_NRF_MOSI_IOMUX                                  (IOMUX_PINCM20)
/* Defines for NRF_MISO: GPIOA.10 with pinCMx 21 on package pin 56 */
#define GPIO_NRF_NRF_MISO_PORT                                           (GPIOA)
#define GPIO_NRF_NRF_MISO_PIN                                   (DL_GPIO_PIN_10)
#define GPIO_NRF_NRF_MISO_IOMUX                                  (IOMUX_PINCM21)
/* Port definition for Pin Group GPIO_ROD_STEPPER */
#define GPIO_ROD_STEPPER_PORT                                            (GPIOB)

/* Defines for ROD_DIR: GPIOB.25 with pinCMx 56 on package pin 27 */
#define GPIO_ROD_STEPPER_ROD_DIR_PIN                            (DL_GPIO_PIN_25)
#define GPIO_ROD_STEPPER_ROD_DIR_IOMUX                           (IOMUX_PINCM56)
/* Defines for ROD_EN: GPIOB.21 with pinCMx 49 on package pin 20 */
#define GPIO_ROD_STEPPER_ROD_EN_PIN                             (DL_GPIO_PIN_21)
#define GPIO_ROD_STEPPER_ROD_EN_IOMUX                            (IOMUX_PINCM49)
/* Port definition for Pin Group GPIO_ROD_ENCODER */
#define GPIO_ROD_ENCODER_PORT                                            (GPIOB)

/* Defines for ROD_ENC_A: GPIOB.0 with pinCMx 12 on package pin 47 */
// pins affected by this interrupt request:["ROD_ENC_A","ROD_ENC_B"]
#define GPIO_ROD_ENCODER_INT_IRQN                               (GPIOB_INT_IRQn)
#define GPIO_ROD_ENCODER_INT_IIDX               (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define GPIO_ROD_ENCODER_ROD_ENC_A_IIDX                      (DL_GPIO_IIDX_DIO0)
#define GPIO_ROD_ENCODER_ROD_ENC_A_PIN                           (DL_GPIO_PIN_0)
#define GPIO_ROD_ENCODER_ROD_ENC_A_IOMUX                         (IOMUX_PINCM12)
/* Defines for ROD_ENC_B: GPIOB.18 with pinCMx 44 on package pin 15 */
#define GPIO_ROD_ENCODER_ROD_ENC_B_IIDX                     (DL_GPIO_IIDX_DIO18)
#define GPIO_ROD_ENCODER_ROD_ENC_B_PIN                          (DL_GPIO_PIN_18)
#define GPIO_ROD_ENCODER_ROD_ENC_B_IOMUX                         (IOMUX_PINCM44)

/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_PWM_MOTOR_init(void);
void SYSCFG_DL_PWM_ROD_STEP_init(void);
void SYSCFG_DL_TIMER_SYS_init(void);
void SYSCFG_DL_I2C_SHARED_init(void);
void SYSCFG_DL_UART_DEBUG_init(void);
void SYSCFG_DL_UART_K230_init(void);
void SYSCFG_DL_UART_JY61P_init(void);


bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */
