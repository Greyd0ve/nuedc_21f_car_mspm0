./objects/app_line.o: ..\App\app_line.c ..\App\app_line.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_config.h \
  ..\App\app_car_state.h ..\Hardware\IR8.h
