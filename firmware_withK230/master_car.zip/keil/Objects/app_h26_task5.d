./objects/app_h26_task5.o: ..\App\app_h26_task5.c ..\App\app_h26_task5.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h \
  ..\App\app_h26_ball_control.h ..\App\app_h26_config.h \
  ..\App\app_config.h ..\App\app_h26_task2.h ..\App\app_control.h
