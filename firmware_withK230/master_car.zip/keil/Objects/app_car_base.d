./objects/app_car_base.o: ..\App\app_car_base.c ..\App\app_car_base.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_config.h \
  ..\App\app_car_state.h ..\App\app_control.h ..\App\app_line.h \
  ..\Hardware\BeepLed.h ..\Hardware\Encoder.h ..\Hardware\Motor.h \
  ..\Hardware\OLED.h ..\Hardware\DebugSerial.h
