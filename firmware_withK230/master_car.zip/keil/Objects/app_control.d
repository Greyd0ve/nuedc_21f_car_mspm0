./objects/app_control.o: ..\App\app_control.c ..\App\app_control.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_config.h \
  ..\App\app_tuning.h ..\App\app_car_state.h ..\Hardware\Encoder.h \
  ..\Hardware\Motor.h ..\Hardware\PWM.h ..\Control\pid.h
