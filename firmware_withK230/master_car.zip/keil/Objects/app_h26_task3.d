./objects/app_h26_task3.o: ..\App\app_h26_task3.c ..\App\app_h26_task3.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_h26_config.h \
  ..\App\app_config.h ..\Hardware\RodStepper.h
