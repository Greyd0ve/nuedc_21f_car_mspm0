./objects/app_h26_led.o: ..\App\app_h26_led.c ..\App\app_h26_led.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_h26_config.h \
  ..\App\app_config.h ..\Hardware\BeepLed.h
