./objects/app_vision_track.o: ..\App\app_vision_track.c \
  ..\App\app_vision_track.h D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h \
  ..\App\app_vision_link.h ..\App\app_config.h ..\App\app_car_state.h \
  ..\App\app_control.h ..\Hardware\DebugSerial.h ..\Hardware\Motor.h
