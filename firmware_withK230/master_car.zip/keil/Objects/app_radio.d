./objects/app_radio.o: ..\App\app_radio.c ..\App\app_radio.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h ..\App\app_config.h \
  ..\Hardware\NRF24L01.h ..\Hardware\DebugSerial.h
