./objects/app_h26_task4.o: ..\App\app_h26_task4.c ..\App\app_h26_task4.h \
  D:\Keil_v5_38a\ARM\ARMCLANG\include\stdint.h \
  ..\App\app_h26_ball_control.h ..\App\app_h26_config.h \
  ..\App\app_config.h ..\App\app_control.h
